<?php
namespace OnHold\Users;
class UserImagesManager{
    const CONTAINER_NAME = "UserImagesManager";

    private $databaseConnection;

    /**
     * 
     * @param type $connection
     */
    public function __construct($connection) {
        $this->databaseConnection = $connection;
    }

    //Deletes de given File
    public function DeleteClientPhoto($ClientID) {
        $PhotoToDelete = glob('../../uploads/host/Host-' . $ClientID . '*');
        if ($PhotoToDelete) {
            unlink($PhotoToDelete['0']);
        }
    }

}










    // //Converts a Base64 string into a JPEG file and returns the path of the file
    // public function Base64ToJPG($ClientID,$photo){
    // $name = "Host-" . $ClientID . "_" . date("Y-m-d H-i-s");
    // $output_file = "../../uploads/host/" . $name . ".jpeg";
    // $output_file = $this->base64_to_jpeg($photo, $output_file);
    // return $name . ".jpeg";
    // }

    // private function base64_to_jpeg($base64_string, $output_file) {
    //     // open the output file for writing
    //     $ifp = fopen($output_file, 'w');
    
    //     // split the string on commas
    //     // $data[ 0 ] == "data:image/png;base64"
    //     // $data[ 1 ] == <actual base64 string>
    //     $data = explode(',', $base64_string);
    
    //     // we could add validation here with ensuring count( $data ) > 1
    //     fwrite($ifp, base64_decode($data[0]));
    
    //     // clean up the file resource
    //     fclose($ifp);
    
    //     return $output_file;
    // }
